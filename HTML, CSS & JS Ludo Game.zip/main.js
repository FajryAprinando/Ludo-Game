import { Ludo } from './ludo/Ludo.js';

const ludo = new Ludo();